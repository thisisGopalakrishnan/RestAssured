package assured;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Dynamicjson {

	@DataProvider(name="API data")
	private Object data_for_API() {
		 return new Object[][] {{"test","4613"},{"checking","9876"}};
	}
	
	@Test(dataProvider = "API data")
	private void addbook(String a , String b) throws IOException {
		RestAssured.baseURI="http://216.10.245.166";
		
		String response = given().log().all().header("Content-Type", "application/json").
		//.body(new String (Files.readAllBytes(Path.of("path of the json"))))
		body(Payload.add_book(a,b))
		.when().post("/Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		JsonPath rawtoJson = Reuseablemethod.RawtoJson(response);
		String int1 = rawtoJson.get("ID");
		System.out.println(int1);
		String object = rawtoJson.getString("Msg");
		System.out.println("New object "+object);
		
	}
	
	
	
}
