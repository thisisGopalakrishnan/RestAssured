package assured;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static org.hamcrest.Matchers.*;

import javax.swing.plaf.metal.MetalBorders.PaletteBorder;

import org.testng.Assert;

import static io.restassured.RestAssured.*;

public class Rest_Assured_POST {
	public static String placeid;
	
	public static void main(String[] args) {
	
		//Given- all inputs
		//When- submit the API -- resource and HTTP method comes into when method
	    //Then - validate the API response
		
		// Add place and update place with new address--> get place the verify the update.
		// Main goal is save the data and reuse the data.
		
		RestAssured.baseURI = "https://rahulshettyacademy.com";
		String response = given().queryParam("key", "qaclick123").header("Content-Type", "application/json")
				.body(Payload.addplace())
				.when().post("maps/api/place/add/json")
				.then().assertThat().statusCode(200).body("scope", equalTo("APP"))
				.header("server", "Apache/2.4.52 (Ubuntu)").extract().response().asString();
	
			System.out.println(response);
		
			// We Extract the data from Json File
			JsonPath rawtoJson3 = Reuseablemethod.RawtoJson(response); // Parsing json 
			String placeid = rawtoJson3.getString("place_id");
		
			String reference = rawtoJson3.getString("reference");
			System.out.println("Place ID  "+placeid); // we extract place id from json File
			System.out.println("reference ID  "+reference); // We Extract placeID from Json File.
			
			// Update method
			
			String newaddress = "chennai siruseri";
			String update_method = given().log().all().queryParam("key", "qaclick123").header("Content-Type", "application/json").body("{\r\n"
					+ "\"place_id\":\""+placeid+"\",\r\n"
					+ "\"address\":\""+newaddress+"\",\r\n"
					+ "\"key\":\"qaclick123\"\r\n"
					+ "}\r\n"
					+ "")
			.when().put("maps/api/place/update/json").then().assertThat().log().all().statusCode(200)
			.body("msg",equalTo("Address successfully updated"))
			.extract().response().asString();

			JsonPath rawtoJson2 = Reuseablemethod.RawtoJson(update_method);
			String address = rawtoJson2.getString("msg");
			System.out.println("Success Msg "+address);
		
			// Once the data updated using get method check the updated details as expected or not
			
			String get_method = given().log().all().queryParam ("key", "qaclick123").header("Content-Type", "application/json").
			when().get("maps/api/place/get/json?place_id="+placeid+"&key=qaclick123").
			then().assertThat().log().all().statusCode(200)
			.body("address", equalTo(newaddress)).extract().response().asString();
			
			JsonPath rawtoJson = Reuseablemethod.RawtoJson(get_method);
			String Actual_addresss = rawtoJson.getString("address");
			System.out.println("Addressed Verify "+Actual_addresss);
			 Assert.assertEquals(newaddress,Actual_addresss );
			 
			 
			

	}}
