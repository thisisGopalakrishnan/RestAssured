package assured;

import org.testng.Assert;
import org.testng.annotations.Test;

import groovyjarjarantlr4.v4.parse.ANTLRParser.id_return;
import io.restassured.path.json.JsonPath;

public class Extract_data_from_Json  {
	
	@Test
	public static void complexJsonparse() {
	JsonPath js = Reuseablemethod.RawtoJson(Payload.mock_data());
	// get the Web site 
	String Website = js.getString("dashboard.website");
	System.out.println("Website "+Website);
	// Number of size
	int int1 = js.getInt("courses.size()");
	System.out.println("Number of courses "+ int1);
	// Title name
	String title = js.getString("courses[0].title");
	System.out.println("first title name "+title);
	
	int int2 = js.getInt("dashboard.purchaseAmount");
	System.out.println("Purchase Amount "+int2);
	
	
	
	for (int i = 0; i < int1; i++) {
		String title1 = js.getString("courses["+i+"].title");
		System.out.println("Title of the Course"+title1);
		int int3 = js.getInt("courses["+i+"].price");
		System.out.println("Price of the course "+int3);
		
	}
	
	int sum = 0;
	for (int i = 0; i < int1; i++) {
		int price = js.getInt("courses["+i+"].price");
		
		int copies = js.getInt("courses["+i+"].copies");
	
		 sum += price * copies;	
		
	}
	
	System.out.println("Total Amount "+sum);
	Assert.assertEquals(int2, sum, "Values not mateched");
	}
	
	
}

/*
 * Json used in this Section with Queries to solve
{

"dashboard": {

"purchaseAmount": 910,

"website": "rahulshettyacademy.com"

},

"courses": [

{

"title": "Selenium Python",

"price": 50,

"copies": 6

},

{

"title": "Cypress",

"price": 40,

"copies": 4

},

{

"title": "RPA",

"price": 45,

"copies": 10

}

]

}



1. Print No of courses returned by API

2. Print Purchase Amount

3. Print Title of the first course

4. Print All course titles and their respective Prices

5. Print no of copies sold by RPA Course

6. Verify if Sum of all Course prices matches with Purchase Amount

*/
