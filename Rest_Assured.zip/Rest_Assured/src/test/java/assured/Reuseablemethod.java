package assured;

import io.restassured.path.json.JsonPath;

public class Reuseablemethod {
	public static  JsonPath RawtoJson(String response) {
		JsonPath js2 = new JsonPath(response);
		return js2;
		

	}
	

}
