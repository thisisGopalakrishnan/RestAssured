package Jira;

import org.testng.annotations.Test;

import assured.Reuseablemethod;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ValidatableResponse;

import static org.hamcrest.Matchers.*;

import javax.swing.plaf.metal.MetalBorders.PaletteBorder;

import org.testng.Assert;

import static io.restassured.RestAssured.*;



public class API_for_Jira {

	@Test
	private void Create_bug_using_API() {
	
		RestAssured.baseURI="https://gopalakrishnanecon.atlassian.net/";
		
		//Given for the setup like parameters headers
		String response =   given().log().all().header("Content-Type", "application/json").header("Authorization","Basic Z29wYWxha3Jpc2huYW4uZWNvbkBnbWFpbC5jb206QVRBVFQzeEZmR0YwUnZnM3VOUFZZTXgxTzFyX0xpUEN4TXdiczhzN0g2Zi11V2paeHU3T05Fa0IzY2YtOUI2YUJJUTM4c2p6dnNET1hFcUZDdnVMOWY2YXE5YmVBNzJiV1dwSHFNZkhldlI5SmJrVExPMVdKa3pQeUZFQkRKYzNDZ2VXNHdjOHVya0hVaV9XNWdFLW1ubGg0NlFWZ3lnMVJCNXVwMmh5amI3OVVmaDV6UUNxa2N3PTJEMkQ0OEU1")
		.body(payload.loadforcreatebug())
		.when().post("rest/api/2/issue")
		.then().log().all().assertThat().statusCode(201).extract().response().asString();
		
	JsonPath js = new JsonPath(response);
	String id = js.getString("id");
	System.out.println(id);
	

	}
	
	
	
	
}
