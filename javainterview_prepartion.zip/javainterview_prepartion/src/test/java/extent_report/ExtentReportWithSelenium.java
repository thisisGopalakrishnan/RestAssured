package extent_report;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import base.Base_Class;

import java.io.IOException;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class ExtentReportWithSelenium extends Base_Class{
    WebDriver driver;
    ExtentReports extent;
    ExtentTest test;

    @BeforeTest
    public void setupReport() {
        ExtentSparkReporter spark = new ExtentSparkReporter("extentReport.html");
        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Tester", "Gopalakrishnan");
        extent.setSystemInfo("Environment", "QA");
    }

    @BeforeMethod
    public void setupDriver() {
    	launch_browser("chrome");
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
    }

    @Test
    public void googleTest() throws WebDriverException, IOException {
        test = extent.createTest("Google Title Test");
        url("https://www.google.com");

        String title = getdriver().getTitle();
        if (title.equals("Googe")) {
            test.pass("Title matched: " + title);
        } else {
        	String path = Screenshot();
//            String screenshotPath = ScreencshotUtil.captureScreenshot(driver, "GoogleTestFail");
            test.fail("Title did not match. Found: " + title)
                .addScreenCaptureFromPath(path);
        }
    }

    @AfterMethod
    public void tearDown() {
        getdriver().quit();
    }

    @AfterTest
    public void generateReport() {
        extent.flush();
    }
}

