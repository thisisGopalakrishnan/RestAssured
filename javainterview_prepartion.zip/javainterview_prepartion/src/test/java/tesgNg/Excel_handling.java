package tesgNg;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Excel_handling {
	
	@DataProvider(name = "exceldata")
	public static Object[][] datafromdataprovider() throws IOException {
		String Filepath = "E:\\New folder\\Downloads\\testdata.xlsx";
		return Excel_handling.data_from_excel(Filepath,"Sheet1");
		
	}
	
	
	public static Object[][]  data_from_excel(String Filepath, String Sheetname) throws IOException {
		
		FileInputStream file = new FileInputStream(Filepath);
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet(Sheetname);
		int rows = sheet.getLastRowNum();
		short cells = sheet.getRow(0).getLastCellNum();
		DataFormatter format = new  DataFormatter();
		Object[][] data = new Object[rows][cells];
		for (int i = 1; i <= rows; i++) {
			XSSFRow row = sheet.getRow(i);
			if (row == null)
				continue;
			for (int j = 0; j < cells; j++) {
				data[i-1][j]= format.formatCellValue(row.getCell(j));
			}
		}
	wb.close();
	return data;
			}
	

	@Test(dataProvider = "exceldata")
	private void datareading(String Username, String password) {
		
		System.out.println("Username "+Username);
		System.out.println("Password "+password);
		
	
	}
	
	
@Test(dataProvider = "exceldata",enabled= false)
private void take_single_row(String Filepath, String Sheetname) throws IOException {
	FileInputStream file = new FileInputStream(Filepath);
	XSSFWorkbook wb = new XSSFWorkbook(file);
	XSSFSheet sheet = wb.getSheet(Sheetname);
	XSSFRow row1 = sheet.getRow(1);	
	for (int i = 0; i <row1.getLastCellNum() ; i++) {
		XSSFCell cell = row1.getCell(i);
		if (cell == null) {
            System.out.print(" [EMPTY] ");
        } else {
            System.out.print(cell.toString() + "  ");
        }
	}
}

@Test()
private static void star() {
	
	WebDriverManager.chromedriver().setup();
	WebDriver driver = new ChromeDriver();
	driver.navigate().to("https://leafground.com/table.xhtml");
	List<WebElement> row2 = driver.findElements(By.xpath("//tr[@data-ri=2]"));
	for (WebElement webElement : row2) {
		String text = webElement.getText();
		System.out.println(text);
	}
	List<WebElement> elements = driver.findElements(By.xpath("//tbody[@id='form:j_idt89_data']//tr"));
	for (WebElement web : elements) {
		
		String text2 = web.getText();
//		System.out.println(text2);
		WebElement element = web.findElement(By.xpath("//td[3]"));
		String webElement = element.getText();		
		System.out.println(webElement);
	}
}




private static Object[][] excel_data_reading() throws IOException {
	FileInputStream file = new FileInputStream(
			"E:\\New folder\\Downloads\\JWALC - e-CAM25_CUONX_H01R1 JWAMP2526-0082_18-Jul-2025_16-36-46.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(file);
	XSSFSheet sheet = wb.getSheet("Job Work Allocation");
	XSSFCell cell2 = sheet.getRow(3).getCell(3);
	int lastRowNum = sheet.getLastRowNum();
	short lastCellNum = sheet.getRow(1).getLastCellNum();
	DataFormatter data = new DataFormatter();
	String s = "ACC-RB-WTB-ADP-H01R1";
	for (Row row : sheet) {
		for (int i = 0; i < row.getLastCellNum(); i++) {
			String formatCellValue = data.formatCellValue(row.getCell(i));
			System.out.print(formatCellValue + "\t");
			if (formatCellValue.equals(s)) {
				String formatCellValue2 = data.formatCellValue(row.getCell(i + 3));
//				System.out.println(formatCellValue2);
				for (Cell cell : row) {
					String formatCellValue3 = data.formatCellValue(cell);
//					System.out.print(formatCellValue3 + "\t");
				}
			}

		}
		System.out.println();
	}
	Object[][] dataa = new Object[lastRowNum][lastCellNum];
	for (int i = 1; i <= lastRowNum; i++) {
		XSSFRow row = sheet.getRow(i);
		for (int j = 0; j < lastCellNum; j++) {
			dataa[i - 1][j] = data.formatCellValue(row.getCell(j));

		}
	}
	// print all the data from excel
	for (Object[] rowData : dataa) {
		for (Object cell : rowData) {
//			System.out.print(cell + "\t");
		}
//		System.out.println();
	}
	return dataa;
}

private void skillcheck() throws IOException {
	FileInputStream file = new FileInputStream("E:\\New folder\\Downloads\\testdata.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook(file);
	XSSFSheet sheet = wb.getSheet("Sheet1");
	DataFormatter format = new DataFormatter();
	String b = "Username";
	
	XSSFRow row2 = sheet.getRow(1);
	
	for (int i = 0; i <=sheet.getLastRowNum(); i++) {
		XSSFRow row = sheet.getRow(i);		
		if (row == null) continue;
//		String a = format.formatCellValue(row.getCell(i));
		for (int j = 0; j <row.getLastCellNum(); j++) {
			String formatCellValue = format.formatCellValue(row.getCell(j));
			System.out.print(formatCellValue+ "\t");
			if (formatCellValue.equalsIgnoreCase(b)) {
				String formatCellValue2 = format.formatCellValue(row.getCell(j));
				System.out.println("Expected thing happened "+formatCellValue2);
				
			}
		}
		
		System.out.println();
		
	}
	
	for (int i = 0; i < row2.getLastCellNum(); i++) {
		
		String formatCellValue = format.formatCellValue(row2.getCell(i));
		System.out.print(formatCellValue+" ");
	}
	
	


}

}
