package tesgNg;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Extent_Report {
	
	public static  ExtentReports report() {
		ExtentReports report = new ExtentReports();
		String timestamp = new SimpleDateFormat("yyyy_MM_dd___HHmmssSSS").format(new Date());
		ExtentSparkReporter report1 = new ExtentSparkReporter("Extend_Repo_TestNG/Run_"+timestamp+"/ExtentReport.html");
		report1.config().setReportName("");
		report1.config().setDocumentTitle("");
		report.attachReporter(report1);
		return report;
	}

}
