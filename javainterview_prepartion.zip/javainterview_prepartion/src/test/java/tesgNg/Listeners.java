package tesgNg;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.IAnnotationTransformer;
import org.testng.IRetryAnalyzer;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.ITestAnnotation;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentReporter;
import com.google.common.io.Files;

import base.Base_Class;
public class Listeners extends Base_Class implements ITestListener, IRetryAnalyzer, IAnnotationTransformer {
	int count =0;
	int maxtry = 2;
	private static ExtentReports extent = Extent_Report.report();
	public static ThreadLocal<ExtentTest> test = new ThreadLocal<>();
	@Override
	public void onTestStart(ITestResult result) {
		ITestListener.super.onTestStart(result);
		ExtentTest test2 = extent.createTest(result.getMethod().getMethodName());
	    test.set(test2);
		System.out.println("On test start method");
	}
	@Override
	public void onTestFailure(ITestResult result) {
		try {
			Screenshot();
		} catch (WebDriverException | IOException e) {
			
			e.printStackTrace();
		}
		ITestListener.super.onTestFailure(result);
		String testName = result.getTestName();
		System.out.println(testName);
		long startMillis = result.getStartMillis();
		System.out.println(startMillis);
		System.out.println("Test has been failed");
		test.get().fail(result.getThrowable());
		String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmssSSS").format(new Date());
		
//		extent.flush();
	}
	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSuccess(result);
		System.out.println("using on test success method test has been success  "+result.getMethod());
		System.out.println(result.getInstanceName()+ result.getName());
		test.get().pass("Test has been passed");
		}
	
	@Override
	public void onFinish(ITestContext context) {
		extent.flush(); // Generates the report
	}
	@Override
	public boolean retry(ITestResult result) {
	
		if (maxtry>count) {
			System.out.println("attemplt of the retry is "+ count);
			Set<String> attributeNames = result.getAttributeNames();
			System.out.println("attributeNames  "+attributeNames);
			count++;
			return true;
		}
		return false;
	}
	 @Override
	    public void transform(
	            ITestAnnotation annotation,
	            Class testClass,
	            Constructor testConstructor,
	            Method testMethod) {
	        annotation.setRetryAnalyzer(Listeners.class);
	    }

}
