package tesgNg;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Executable;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.io.Files;

import base.Base_Class;
import io.cucumber.java.it.Data;
import io.github.bonigarcia.wdm.WebDriverManager;
import com.aventstack.extentreports.ExtentReports;

//@org.testng.annotations.Listeners(Listeners.class)
public class TestNG extends Base_Class {
	@Test(retryAnalyzer = Listeners.class, enabled = false)
	private static void first_test() throws InterruptedException {
		long timeMillis = System.currentTimeMillis();
		Date start = new Date(timeMillis);
		System.out.println("Start " + start);
		Thread.sleep(100);
		long endtimills = System.currentTimeMillis();
		Date end = new Date(endtimills);
		System.out.println("End " + end);
		long total = endtimills - timeMillis;
		System.out.println(total);
		long minutes = total / (1000 * 60);
		long seconds = (total / 1000) % 60;
		System.out.println(minutes + " minutes and seconds " + seconds);

		Assert.fail();
	}

	@Test(enabled = false, dependsOnMethods = { "javascript" })
	private void second_test() throws AWTException, InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://leafground.com/table.xhtml");
		driver.manage().window().maximize();
		// get the value from particular row and particular cell
		WebElement element2 = driver.findElement(By.xpath("(//tbody/tr[.//td[@role='gridcell']])[4]"));
		List<WebElement> elements = element2.findElements(By.xpath(".//td[@role='gridcell']"));
		for (WebElement webElement : elements) {
			String text = webElement.getText();
			System.out.println("Particualr row " + text);
		}
		WebElement element = element2.findElement(By.xpath("./td[3]"));
		String text = element.getText();
		System.out.println("Single cell value " + text);

		// looping to get the row and cell value
		List<WebElement> rows = driver.findElements(By.xpath("//tbody/tr[.//td[@role='gridcell']]"));
		for (WebElement row : rows) {
			List<WebElement> cells = row.findElements(By.xpath(".//td[@role='gridcell']"));
			if (cells.size() > 4) {
				WebElement webElement = cells.get(4);
				String text2 = webElement.getText();
				System.out.println(text2);
			}
			// printing all row and cell value.
			for (WebElement cell : cells) {
				String text2 = cell.getText();
				System.out.print(text2 + "\t");
			}
		}
	}

	@Test(enabled = false)
	private void javascript() throws IOException {
		launch_browser("edge");
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
		String property = System.getProperty("user.dir");
		System.out.println(property);
		File folder = new File("D:\\ERP\\Gopal");
		folder.mkdirs();
		getdriver().get("https://leafground.com/dashboard.xhtml");
		getdriver().manage().window().maximize();
		WebElement element = getdriver().findElement(By.cssSelector("#email"));
		JavascriptExecutor js = (JavascriptExecutor) getdriver();
		js.executeScript("arguments[0].value='selenium';", element);
		js.executeScript("window.scrollBy(0,1000);");
		WebElement element2 = getdriver().findElement(By.xpath("//i[@class='pi pi-table layout-menuitem-icon']"));
		js.executeScript("arguments[0].click();", element2);

		// Screenshot
		getdriver().get("");
	}

	@Test(enabled = false)
	private static void pdf_validation() throws IOException {

		File a = new File("E:\\New folder\\Downloads\\Java Selenium 4yrs Qb.pdf");
		PDDocument pdDocument = PDDocument.load(a);
		
		PDFTextStripper stripper = new PDFTextStripper();
		String pdftext = stripper.getText(pdDocument);
		// System.out.print(pdftext+"\t");
		String b = "abstract";
		for (int i = 0; i < pdftext.length(); i++) {
			if (b.contains(pdftext)) {
				System.out.println("Hiiiiiiiiiiiii  " + b);
			}
 
		}
		if (pdftext.contains("abstract")) {
			System.out.println("✅ PDF contains the expected text");
		} else {
			System.out.println("❌ Expected text not found in PDF");
		}

	}

	@DataProvider(name = "data", parallel = false)
	public Object[][] simple() {
		return new Object[][] { { "admin" , "admin@123"}, { "admin2" ,"admin321"},
		{"Single diamention","two Diamention"}
		};
	}

	@Test(dataProvider = "data", enabled = true)
	private void test(String username, String password) {
		System.out.println("User name " + username);
		System.out.println("User password " + password);
	}

	@Test(invocationCount = 3, skipFailedInvocations = true, enabled = false)
	public static void addtwo_numbers() {
		int a = 2;
		int b = 3;
		System.out.println(a + b);
		Assert.fail();

	}

	@DataProvider(name = "Excel data")
	public Object[][] getdata() throws IOException {
		FileInputStream file = new FileInputStream(
		"C:\\Users\\GopalakrishnanG\\eclipse-workspace\\javainterview_prepartion\\src\\main\\resources\\Excel datafile\\partnumber_compare.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("Sheet1");
		String a = "TPS62290DRVT";
		DataFormatter format = new DataFormatter();
		XSSFCell cell = sheet.getRow(1).getCell(1);
		XSSFRow row3 = sheet.getRow(1);
		short lastCellNum2 = row3.getLastCellNum();
		for (int i = 0; i < row3.getLastCellNum(); i++) {
			String formatCellValue = format.formatCellValue(row3.getCell(i));
			System.out.println("Printing particular row " + formatCellValue);
		}

		System.out.println("Value pf cell " + cell);
		for (Row row : sheet) {
			for (int i = 0; i < row.getLastCellNum(); i++) {
				String formatCellValue = format.formatCellValue(row.getCell(i));
//	System.out.println("All cell values "+formatCellValue+"\t");
				if (a.equalsIgnoreCase(formatCellValue)) {
					String excepected = format.formatCellValue(row.getCell(i + 1));
					System.out.println("Expected cell value " + excepected);
					for (Cell row2 : row) {
						String formatCellValue2 = format.formatCellValue(row2);
						System.out.println("target row  " + formatCellValue2);
					}
					break;
				}
			}

		}
		int lastRowNum = sheet.getLastRowNum();
		int lastCellNum = sheet.getRow(0).getLastCellNum(); // header row

		Object[][] data = new Object[lastRowNum][lastCellNum]; // only Username & Password

		for (int i = 1; i <= lastRowNum; i++) {
			XSSFRow currentRow = sheet.getRow(i);
			if (currentRow == null)
				continue;

			for (int j = 0; j < lastCellNum; j++) {
				data[i - 1][j] = format.formatCellValue(currentRow.getCell(j));
			}
		}

		wb.close();
		return data;
	}

	@Test(dataProvider = "Excel data", enabled = false)
	private void extractdata(String Username, String Password, String no) throws IOException {
		Object[][] getdata = getdata();
		String string = getdata[1][1].toString();
		System.out.println("Value of the String " + string);

		System.out.println(Username + "  " + Password);
	}
@Test(enabled=false)
private void Verify_download() throws InterruptedException {
	 String downloadPath = "E:\\DiaCAM\\SAS\\5MP";
	
     // Count files before download
     int beforeCount = new File(downloadPath).listFiles().length;
     System.out.println(beforeCount);
     
     // 👉 Trigger download in Selenium here
     // driver.findElement(By.id("downloadButton")).click();

     // Wait for new file
     boolean downloaded = false;
     int retries = 30; // 30 seconds max
     int count = 1;
     while (retries > count) {
         int afterCount = new File(downloadPath).listFiles().length;
         if (afterCount > beforeCount) {
             downloaded = true;
             break;
         }
         Thread.sleep(1000);
         count++;
     }

     if (downloaded) {
         System.out.println("✅ New file downloaded successfully!");
     } else {
         System.out.println("❌ No new file detected.");
     }
}

@Test(enabled = false)
public static void properties() throws IOException {

	Properties prop = new Properties();
	FileInputStream file = new FileInputStream("C:\\Users\\GopalakrishnanG\\eclipse-workspace\\javainterview_prepartion\\src\\test\\resources\\property file\\config.properties");
	
	prop.load(file); // using load keyword we have to load the pro file 
	
	
	String url = prop.getProperty("url");
	String username = prop.getProperty("username");
	String browser = prop.getProperty("browser");
	System.out.println("Url has "+url);
	System.out.println("Username "+username);
	System.out.println("browser name "+browser);
	LocalDateTime now = LocalDateTime.now();
	System.out.println("Current data Time "+now);
	
}

}
