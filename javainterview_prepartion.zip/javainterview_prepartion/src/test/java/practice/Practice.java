package practice;

import java.awt.print.Printable;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyStore.Entry;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ForkJoinPool;
import java.util.jar.Attributes.Name;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.poi.ss.formula.atp.Switch;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jspecify.annotations.Nullable;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.annotation.JacksonInject.Value;
import com.google.common.io.Files;

import org.testng.asserts.SoftAssert;

import base.Base_Class;
import base.Excel_data;
import io.cucumber.java.it.Data;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.reactivex.rxjava3.internal.operators.observable.ObservableTakeWhile;
import sun.net.www.protocol.http.HttpURLConnection;
import tesgNg.Excel_handling;

public class Practice extends Base_Class {

	private static WebElement element;

	private static void finding_vowels_and_count() {
		String name = "sheikprincep";
		String vowels = "aeiou";

		char[] ch = name.toCharArray();
		char[] ch1 = vowels.toCharArray();

		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == 0)
				continue;
			int count = 1;
			for (int j = 0; j < ch1.length; j++) {
				if (ch[i] == ch1[j]) {
					System.out.println("Vowels present in the name " + ch[i]);
					count++;
					ch[j] = 0;

				}
			}
			if (count == 1) {
				System.out.println("appeared only once in the name  " + ch[i] + " " + count);
			} else {
				System.out.println("appeared twice in the name " + ch[i] + " " + count);

			}
		}

	}

	private static void add_twonumbers() {

		int[] a = { 1, 2, 3 };
		int[] b = { 4, 3, 2 };
		int[] h = new int[b.length];
		int c = 0;
		int d = 0;
		int rev = 0;
		int rev1 = 0;
		for (int num : a) {
			c = c * 10 + num;
		}
		System.out.println("converted the number into INT  " + c);

		for (int num : b) {
			d = d * 10 + num;
		}
		System.out.println("converted the number into INT  " + d);

		while (c != 0) {
			System.out.println(c);
			int digit = c % 10;
			System.out.println(digit);
			rev = rev * 10 + digit;
			c = c / 10;
			System.out.println("Value of C  " + c);
		}
		System.out.println("Reversed number " + rev);
	}

	private static void wise_ve_string() {
		String a = "ANImal";
		char[] ch = a.toCharArray();
		StringBuilder s = new StringBuilder();
		for (int i = 0; i < ch.length; i++) {
			if (Character.isUpperCase(ch[i])) {
				char lowerCase = Character.toLowerCase(ch[i]);
				s.append(lowerCase);
			}
			if (Character.isLowerCase(ch[i])) {
				char upper = Character.toUpperCase(ch[i]);
				s.append(upper);
			}

		}
		String m = new String(s.toString());
		System.out.print(m);

	}

	private static void add_two_numbers() {
		int[] a = { 1, 2, 3, 4, 5 };
		int sum = 0;
		int le = a.length - 1;
		int len = a.length;
		int firstindex = a[0];
		int lastindex = 0;
		int totalsum = 0;

		System.out.println(len);

		for (int i = 0; i < a.length; i++) {
			// we can find the last index
			lastindex = a[i] - 1;
			totalsum += a[i];

		}
		sum = firstindex + lastindex;
		System.out.println("sum of the first index and last index " + sum);
		System.out.println("Total sum of the index " + totalsum);

	}

	private static void add_twonumbers_() {
		int[] a = { 1, 2, 3, 4, 5 };
		int sum = 0;
		int firstnum = 0;
		int secondnum = 0;
		for (int i = 0; i < a.length; i++) {

			if (a[i] == 4) {
				firstnum = a[i];
			}
			if (a[i] == 2) {
				secondnum = a[i];
			}
			for (int j = 0; j < a.length; j++) {
				if (a[i] + a[j] == 7) {
					System.out.println("number of " + a[i] + " and " + a[j]);
				}

			}
		}
		sum = firstnum + secondnum;
		System.out.println("total of the two numbers " + sum);

	}

	private static void string_rev() {
		String s = "abc de";
		String[] split = s.split(" ");
		StringBuilder a = new StringBuilder();
		for (int i = 0; i < split.length; i++) {

			if (split[i].equalsIgnoreCase("de")) {
				String d = new StringBuilder(split[i]).reverse().toString();
				a.append(d);
			}
//			else {
//			String m = new StringBuilder(split[i]).reverse().toString();
//			a.append(m);
//			}
		}
		String j = new String(a.toString());
		System.out.println(j);

	}

	private static void String_list() {
		String a = "ab cde";
		int indexOf = a.indexOf(" ");
		String replace = a.replace(" ", "");
		String w = new StringBuilder(replace).reverse().toString();
		StringBuilder m = new StringBuilder(w);
		StringBuilder insert = m.insert(indexOf, " ");
		System.out.println(insert);
	}

	private static Object[][] excel_data_reading() throws IOException {
		FileInputStream file = new FileInputStream(
				"E:\\New folder\\Downloads\\JWALC - e-CAM25_CUONX_H01R1 JWAMP2526-0082_18-Jul-2025_16-36-46.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("Job Work Allocation");
		XSSFCell cell2 = sheet.getRow(3).getCell(3);
		int lastRowNum = sheet.getLastRowNum();
		short lastCellNum = sheet.getRow(1).getLastCellNum();
		DataFormatter data = new DataFormatter();
		String s = "ACC-RB-WTB-ADP-H01R1";
		for (Row row : sheet) {
			for (int i = 0; i < row.getLastCellNum(); i++) {
				String formatCellValue = data.formatCellValue(row.getCell(i));
				System.out.print(formatCellValue + "\t");
				if (formatCellValue.equals(s)) {
					String formatCellValue2 = data.formatCellValue(row.getCell(i + 3));
//					System.out.println(formatCellValue2);
					for (Cell cell : row) {
						String formatCellValue3 = data.formatCellValue(cell);
//						System.out.print(formatCellValue3 + "\t");
					}
				}

			}
			System.out.println();
		}
		Object[][] dataa = new Object[lastRowNum][lastCellNum];
		for (int i = 1; i <= lastRowNum; i++) {
			XSSFRow row = sheet.getRow(i);
			for (int j = 0; j < lastCellNum; j++) {
				dataa[i - 1][j] = data.formatCellValue(row.getCell(j));

			}
		}
		// print all the data from excel
		for (Object[] rowData : dataa) {
			for (Object cell : rowData) {
//				System.out.print(cell + "\t");
			}
//			System.out.println();
		}
		return dataa;
	}

	private static void star_pattern() {
		for (int i = 0; i <= 5; i++) {
			for (int j = 5 - i; j > 0; j--) {
				System.out.print(" ");
			}
			for (int j = 0; j <= i; j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}

	private static void right_star_pattern() {
		for (int i = 0; i <= 5; i++) {
			for (int j = 5 - i; j > 0; j--) {
				System.out.print("*");
			}
//			for (int j = 0; j <=i; j++) {
//				System.out.print("*");
//			}
			System.out.println();
		}
	}

	private static void vowel_count() {
		String a = "aapple";
		String b = "aeiou";
		char[] ch1 = a.toCharArray();
		char[] ch2 = b.toCharArray();

		for (int i = 0; i < ch1.length; i++) {
			if (ch1[i] == 0)
				continue;
			int count = 0;
			for (int j = 0; j < ch2.length; j++) {
				if (ch1[i] == ch2[j]) {
					System.out.println("Vowels in the letter is " + ch1[i]);
					count++;
					ch2[j] = 0;
				}
			}
			if (count == 1) {
				System.out.println("Vowels in the letter is apperaed once " + ch1[i] + "  " + count);
			} else {

				// System.out.println("Vowels in the letter is apperaed twice " + ch1[i] + " " +
				// count);

			}

		}
	}

	private static void Stringoccurance() {

		String a = "aapple";
		char[] ch = a.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == 0)
				continue;
			int count = 1;
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					count++;
					ch[j] = 0;
				}
			}
			if (count == 1) {
				System.out.println(count + " " + ch[i]);
			}
		}
	}

	private static void changing_value() {
		double a = 3.5d;
		int b = (int) Math.round(a);
		int c = (int) 12.36;
		double d = (double) c, f = 13.90;
		float g = 11.987f;
		int k = (int) g;
		System.out.println(c);
		System.out.println(b);
		System.out.println(d);
		System.out.println(f);
		System.out.println(g);
		System.out.println(k);
	}

	private static void prefix() {
		String[] a = { "flower", "float", "floor" };
		String[] b = { "education", "information", "communication" };
		String prefix = a[0];
		String surffix = b[0];
		for (int i = 0; i < a.length; i++) {
			while (!a[i].startsWith(prefix)) {
				prefix = prefix.substring(0, prefix.length() - 1);
			}
		}
		System.out.println(prefix);

		for (int i = 0; i < b.length; i++) {
			while (!b[i].endsWith(surffix)) {
				surffix = surffix.substring(1);
			}

		}
		System.out.println("Surffix " + surffix);

	}

	private static void array_to_int_conversation() {
		ArrayList<Integer> d = new ArrayList<>();
		int[] a = { 1, 2, 3, 4, 5 };
		int b = 0;
		int rev = 0;
		for (int i : a) {
			while (i != 0) {
				int digit = i % 10;
				b = b * 10 + digit;
				i = i / 10;
			}
		}
		System.out.println(b);

		while (b != 0) {
			int digit = b % 10;
			rev = rev * 10 + digit;
			b = b / 10;
		}
		System.out.println(rev);

		while (rev != 0) {
			int digit = rev % 10;
			if (d.add(digit)) {
			}
			rev = rev / 10;
		}
		System.out.print(d);
	}

	private static void xylam() {
		int[] a = { 1, 4, 4 };
		int b = 0;
		int c = 0;
		for (int i = 0; i < a.length; i++) {
			if (i == a.length - 1) { // when it's the last element
				b = a[i];
				System.out.println(b); // print only last digit
			}

			c = a[0] + b;
		}
		if (c == a[1]) {
			System.out.println("Yes it has xylam number");

		} else {
			System.out.println("No its not a xylam number");
		}

	}

	public static void min_in_mul_array() {
		int[] a = { 1, 2, 3, 4 }, b = { 2, 3, 0, 4, 5 };
		int rev = 0;
		for (int i : b) {
			int f = i % 10;
			rev = rev * 10 + f;
			i = i / 10;
		}
		System.out.println(rev);

		int min = a[0];
		int min2 = b[0];
		for (int i = 0; i < a.length; i++) {
			if (a[i] < min) {
				min = a[i];
			}

		}
		for (int i = 0; i < b.length; i++) {
			if (b[i] < min) {
				min2 = b[i];
			}

		}

		for (int i = 0; i < a.length; i++) {
			if (a[i] == 2) {
				System.out.println("Yes number 2 present in the Array");
				break;
			}
		}
		int c = min2 < min ? min2 : min;

		System.out.println(c);
	}

	private static void revers() {

		String a = "hi hello welcome";
		String replace = a.replace(" ", "");
		char[] ch = replace.toCharArray();
		String[] spt = a.split(" ");
		StringBuilder s = new StringBuilder();
		System.out.println(spt[2]);

		for (String string : spt) {
			if (string.equals("hello")) {
				String d = new StringBuilder(string).reverse().toString();
				s.append(d + " ");
			} else {
				s.append(string + " ");
			}

		}

		String sorted = new String(s).toString();
		System.out.println(sorted);

		for (char string2 : ch) {
			if (Character.isLowerCase(string2)) {
				char upperCase = Character.toUpperCase(string2);
				System.out.print(upperCase);
			}
		}
	}

	@DataProvider(name = "test")
	private Object data() throws IOException {
//		 return new Object[][]  {{"Gopal","Love automation"}};
		String path = "E:\\New folder\\Downloads\\testdata.xlsx";
		return Excel_handling.data_from_excel(path, "Sheet1");

	}

	
	private static void star() throws InterruptedException, IOException {
//
		Integer[][] nestedArray = { { 1, 2 }, { 3, 4 }, { 5, 6 } };

		List<Integer> flatArray = Arrays.stream(nestedArray)
		 .flatMap(Arrays::stream).collect(Collectors.toList());
		
//list to int 
			
		System.out.println(flatArray);
		int s = flatArray.stream().mapToInt(Integer::intValue)
         .max().orElseThrow();
		System.out.println(s);
//

		Integer[] numbers = {5, 12, 3, 18, 7};

		List<Integer> bigNumbers = Arrays.stream(numbers)
		                                 .filter(g -> g > 10)
		                                 .toList();

		System.out.println(bigNumbers);
		
//	

		int[] b = { 1, 2, 3, 4 };

		int d = Arrays.stream(b).sum();
		System.out.println(d);
		
		int a = Arrays.stream(b).max().orElseThrow();
		System.out.println(a);
		
//
		String[][] nest = { { "apple", "banana" }, { "cat", "apple" } };

		Set<String> x = Arrays.stream(nest).flatMap(Arrays::stream).collect(Collectors.toSet());

		System.out.println(x);
	}

	@Test()
	private void skillcheck() throws IOException {

		
		
	}
		
		
	    

		
	

	public static void main(String[] args) throws IOException {
//		finding_vowels_and_count();
//	add_twonumbers();
//	wise_ve_string();
//	add_two_numbers();
//	add_twonumbers_();
//		string_rev();
//		String_list();
//		excel_data_reading();
//		Object[][] excel_data_reading = excel_data_reading();
//		String string = excel_data_reading[4][5].toString();
//		System.out.println();
//		System.out.println("Data extract from excel "+string);
//		 star_pattern();
//		 right_star_pattern();
//		vowel_count();
//		Stringoccurance();
//		changing_value();
//		prefix();
//		array_to_int_conversation();
//		 xylam();
//		min_in_mul_array();
//		revers();
//		star();
	}
}
