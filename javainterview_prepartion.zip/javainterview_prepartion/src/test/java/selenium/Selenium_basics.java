package selenium;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Window;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.xml.xpath.XPath;
import org.jspecify.annotations.Nullable;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.github.dockerjava.api.model.Links;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import base.Base_Class;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Selenium_basics  extends Base_Class{

	public static void iframe() {

		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://leafground.com/");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//i[@class=\"pi pi-globe layout-menuitem-icon\"]")).click();
		driver.findElement(By.xpath("//li[@id=\"menuform:m_frame\"]")).click();
		driver.switchTo().frame(2);
		driver.switchTo().frame("frame2");
		driver.findElement(By.xpath("(//button[@onclick=\"change()\"])[1]")).click();
		driver.close();
	}

	public static void switch_to_window() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/");
		driver.findElement(By.xpath("//i[@class=\"pi pi-globe layout-menuitem-icon\"]")).click();
		driver.findElement(By.xpath("//li[@id=\"menuform:m_window\"]")).click();
		String oldwindow = driver.getWindowHandle();
		System.out.println("Window count before click: " + driver.getWindowHandles().size());
		driver.findElement(By.xpath("(//span[@class=\"ui-button-text ui-c\"])[2]")).click();
		List<String> a = new ArrayList<>(driver.getWindowHandles());
		
		for (String string : a) {
			
			@Nullable
			String title = driver.switchTo().window(string).getTitle();
			System.out.println(title);
		}
		
		System.out.println("Window count before click: " + driver.getWindowHandles().size());
		if (a.size() >= 1) {
		    driver.switchTo().window(a.get(1));  // second tab
		    @Nullable
			String title = driver.getTitle();
		    System.out.println(title);
		} else {
		    throw new RuntimeException("Second tab not found!");
		}
		if (a.size() >= 1) {
		    driver.switchTo().window(a.get(2));  // second tab
		    @Nullable
			String title = driver.getTitle();
		    System.out.println(title);
		} else {
		    throw new RuntimeException("Second tab not found!");
		}
		driver.switchTo().window(oldwindow);
		System.out.println(driver.getTitle());
//		WebDriverWait wait = new  WebDriverWait(driver, Duration.ofSeconds(10));
//		wait.until(ExpectedConditions.numberOfWindowsToBe(2));
//		
//		WebDriver window = driver.switchTo().window(a.get(1));
		
//		@Nullable
//		String title = ((WebDriver) a).getTitle();		
//		System.out.println(title);
		
		
		
		
//		Set<String> Newwindow = driver.getWindowHandles();
//		Thread.sleep(1000);
//		for (String NewWin : Newwindow) {
//			driver.switchTo().window(NewWin);
//			driver.findElement(By.xpath("(//input[@type='text'])[1]")).sendKeys("Hello");
//		}
//
//		driver.switchTo().window(oldwindow);
//		driver.findElement(By.xpath("(//span[@class=\"ui-button-text ui-c\"])[3]")).click();
//		Set<String> Multiwindow = driver.getWindowHandles();
//		String closewindow = "Dashboard";
//		for (String Windowmuliple : Multiwindow) {
//			driver.switchTo().window(Windowmuliple);
////			if (!Windowmuliple.equals(closewindow)) {
////				driver.switchTo().window(closewindow);
//			@Nullable
//			String title = driver.getTitle();
//			System.out.println(title);
//			if (!title.equals(closewindow)) {
//				driver.close();
//			}
//
//		}

	}

	public static void robot_class() throws AWTException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/");
		driver.findElement(By.xpath("//li[@id='menuform:j_idt40']")).click();
		WebElement element = driver.findElement(By.xpath("//span[normalize-space()='Dropdown']"));
		element.click();
		driver.findElement(By.xpath("//select[@class='ui-selectonemenu']")).click();
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyRelease(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	private static void movetoelement() throws InterruptedException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/menu");
		Thread.sleep(2000);
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1000);");
//		driver.findElement(By.id("item-7")).click();
		WebElement element = driver.findElement(By.xpath("//a[normalize-space()='Main Item 2']"));
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
		Thread.sleep(2000);
		WebElement element2 = driver.findElement(By.xpath("//a[text()='SUB SUB LIST »']"));

		action.moveToElement(element2).perform();

		@SuppressWarnings("deprecation")
		@Nullable
		String attribute = element2.getAttribute("value");
		System.out.println(attribute);

		Thread.sleep(2000);
		WebElement element3 = driver.findElement(By.xpath("//a[text()='Sub Sub Item 2']"));
		action.moveToElement(element3).perform();

	}

	private static void dropdown() throws InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/select.xhtml");
		String timestamp = new SimpleDateFormat("dd_MM_yyyy").format(new Date());
		System.out.println(timestamp);
		WebElement element = driver.findElement(By.xpath("//select[@class='ui-selectonemenu']"));
		element.sendKeys("Selenium");
		Thread.sleep(2000);
		Select s = new Select(element);
		List<WebElement> options = s.getOptions();
		int size = options.size();
       for (WebElement webElement : options) {
    	System.out.println(webElement.getText()	);
	
}
		for (int i = 0; i < options.size(); i++) {
			s.selectByIndex(i);
			WebElement firstSelectedOption = s.getFirstSelectedOption();
			String tagName = firstSelectedOption.getText();
			System.out.println(tagName);
//	System.out.println(webElement.getText());

		}

	}

	private static void links() throws MalformedURLException, IOException {
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://leafground.com/link.xhtml");

		@Nullable
		String title = driver.getTitle();
		System.out.println("Page Title  " + title);
		// get Attribute from Input tag
		WebElement element = driver.findElement(By.xpath("(//input[@type='hidden'])[1]"));
		@Nullable
		String attribute = element.getAttribute("name");
		System.out.println(attribute);

// click link by linktext
		// WebElement element = driver.findElement(By.linkText("Broken?"));
//		element.click();
// click link  by partial link
		driver.findElement(By.partialLinkText("How many links in this page?")).click();
		List<WebElement> elements = driver.findElements(By.tagName("a"));
		for (WebElement webElement : elements) {
			String text = webElement.getText();
			System.out.println("LInk Text   " + text);
			Dimension size = webElement.getSize();
			System.out.println("Dimension  " + size);
		}

	}
	
	private static void brokenlink() {
		launch_browser("edge");
		url("https://www.amazon.in/");
		List<WebElement> links = getdriver().findElements(By.tagName("a"));
		int size = links.size();
		System.out.println(size);
		 for (WebElement link : links) {
	            String url = link.getAttribute("href");

	            if (url == null || url.isEmpty() || url.startsWith("javascript")) {
	                continue; // Skip empty or JavaScript links
	            }

	            try {
	                // Open connection
	                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
	                conn.setRequestMethod("HEAD");
	                conn.connect();

	                int responseCode = conn.getResponseCode();

	                // Print broken links (response code 400 or more)
	                if (responseCode >= 400) {
	                    System.out.println("Broken link: " + url + " => " + responseCode);
	                } else {
	                    System.out.println("Valid link: " + url);
	                }
	            } catch (Exception e) {
	                System.out.println("Error checking link: " + url + " => " + e.getMessage());
	            }
		 }
	}
	
		@Test
		private static void webtable() {
		launch_browser("chrome");
		url("https://leafground.com/table.xhtml");
		List<WebElement> webtable= getdriver().findElements(By.xpath("//tr[@data-ri=\"1\"]//parent::tbody"));
		WebElement element = getdriver().findElement(By.xpath("//tr[@data-ri='0']"));
		List<WebElement> cell = element.findElements(By.xpath(".//td[@role='gridcell']"));
	
		for (WebElement webElement : cell) {
			System.out.println(webElement.getText());
		}
		
//using the xpath we can take the particular column
		List<WebElement> elements = getdriver().findElements(By.xpath("//tbody[@id='form:j_idt89_data']//tr/td[3]"));
	
		for (WebElement webElement : elements) {
			String tagName = webElement.getText();
			System.out.println("Represenative name = "+tagName);
			
		}
//		 List<WebElement> countryColumn = getdriver().findElements(
//	                By.xpath("//table[@role='grid']//tr/td[2]")
//	        );
//
//	        // Print each country
//	        for (WebElement country : countryColumn) {
//	            System.out.println(country.getText());
//	        }
		
		
//		for (WebElement webElement : webtable) {
//			String text = webElement.getText();
//			System.out.println(text+" \t");
//		}
		
		
	}
		
		
		private void calender() throws InterruptedException {
			launch_browser("edge");
			url("https://www.makemytrip.com/?utm_source=chatgpt.com");
			Thread.sleep(1000);
//			Alert a = getdriver().switchTo().alert();
			getdriver().findElement(By.xpath("//span[@data-cy='closeModal']")).click();
			Thread.sleep(2000);
			getdriver().findElement(By.xpath("//span[@data-cy='travel-card-close']")).click();
			Thread.sleep(1000);
			WebElement element = getdriver().findElement(By.xpath("//p[@data-cy='departureDate']"));
			element.click();
			JavascriptExecutor js = (JavascriptExecutor) getdriver();
//			js.executeScript("window.scrollBy(0,500);");
//			js.executeScript("arguments[0].click();", element);
			
			WebElement month = getdriver().findElement(By.xpath("//p[@data-cy='departureDate']"));
			String monthtext = month.getText();
			WebElement nextbutton = getdriver().findElement(By.xpath("//span[@aria-label=\"Next Month\"]"));
			String nextbuttontext3 = nextbutton.getText();
			
			String text = getdriver().findElement(By.xpath("(//div[@role=\"heading\"])[1]")).getText();
			System.out.println(text);
			
			while(true) {
				
				String text1 = getdriver().findElement(By.xpath("(//div[@role=\"heading\"])[1]")).getText();
				System.out.println(text1);
				
				if (text1.equals("November 2025")) {
					break;
				}else {
					nextbutton.click();	
				}
			}
			Thread.sleep(2000);
			//refetceh the element cuz of staleelement.
			WebElement date = getdriver().findElement(By.xpath("//p[text()='18']"));
			String datetext2 = date.getText();
			date.click();
			
			
			

		}
	
		public static void main(String[] args)
			throws InterruptedException, AWTException, MalformedURLException, IOException {
//		switch_to_window();
//		robot_class();
//		movetoelement();
//		dropdown();
//		links();
//		brokenlink();
//		web_table();
	}

}
