package javainterview_prepartion;

import java.util.Arrays;
import java.util.Iterator;

import org.apache.poi.hssf.record.chart.ChartEndBlockRecord;

public class Stringprograms {
	private static void duplicate_based_string_program() {
		String na = "GOPALAKRISHNAN";
		String name = na.toLowerCase();
		int a = 0, e = 0, i1 = 0, o = 0, u = 0;
		// TO FIND LENGTH OF THE CHARATER
		char[] ch = na.toCharArray();
		System.out.println("Length of the character  " + ch.length);
		// TO FIND VOWELS IN THE GIVEN STRING
		String Vowel = "aeiouAEIOU";
		char[] ch1 = Vowel.toCharArray();
		for (int i = 0; i < name.length(); i++) {
			char charAt = name.charAt(i);
			if (charAt == 'a')
				a++;
			else if (charAt == 'e')
				e++;
			else if (charAt == 'i')
				i1++;
			else if (charAt == 'o')
				o++;
			else if (charAt == 'u')
				u++;
			for (int j = 0; j < Vowel.length(); j++) {

				if (name.charAt(i) == Vowel.charAt(j)) {
					System.out.println("Vowels present in the name  " + name.charAt(i));
				}
			}

		}
		if (a > 0)
			System.out.println("In the name VOWELS present a " + a + "  Times");

	}

	private static void asce_desc_string() {
		String a = "qwerty";
		char[] charArray = a.toCharArray();
		// first index of the variable
		System.out.println("First index value " + charArray[0]);

		for (int i = 0; i < charArray.length; i++) {
//			char c = charArray[i];
			for (int j = i + 1; j < charArray.length; j++) {
//				char c1 = charArray[j];
				if (charArray[i] > charArray[j]) {
					char temp = charArray[i];
					charArray[i] = charArray[j];
					charArray[j] = temp;
				}
			}
		}
		String sorted = new String(charArray);
		System.out.println(sorted);

	}

	private static void duplicate_string() {
		String name = "gopalakrishnan";
		char[] ch = name.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			int count = 1;
			if (ch[i] == 0)
				continue;

			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					count++;
					ch[j] = 0;
				}
			}
			if (count > 1)
				System.out.println("duplicates Chartceters  " + ch[i] + " count  " + count);
			if (count == 1)
				System.out.println("Unique Charatcters  " + ch[i] + " count " + count);

		}
	}

	private static void resverse_string() {
		String name = "I love you";
		String[] split = name.split(" ");
		StringBuilder s = new StringBuilder();
		for (String rev : split) {
			if (rev.equalsIgnoreCase("you")) {
				String a = new StringBuilder(rev).reverse().toString();
				s.append(a);
			} else {
				s.append(rev);
			}
		}
		String sorted = new String(s.toString().trim());
		System.out.print(sorted);
	}

	private static void second_largest_charcter() {

		String alpha = "abcdefg";
		char[] ch = alpha.toCharArray();
		char firstlargest = 0;
		char secondlargest = 0;
		char third = 0;

		for (int i = 0; i < alpha.length(); i++) {
			char ch1 = alpha.charAt(i);

			if (ch1 > firstlargest) {
				third = secondlargest;
				secondlargest = firstlargest;
				firstlargest = ch1;
			} else if (ch1 > secondlargest && ch1 != firstlargest) {
				third = secondlargest;
				secondlargest = ch1;
			} else if (ch1 > third && ch1 > secondlargest && ch1 != firstlargest) {
				third = ch1;
			}

		}

		System.out.println("Second largest charater " + third);

	}

	private static void reeverse() {

		String a = "malayalam";
		String b = "";
		for (int i = a.length() - 1; i >= 0; i--) {
			char charAt = a.charAt(i);
			b += charAt;
		}
		if (a == b) {
			System.out.println("Yes its a palindrome");

		}
		System.out.println(b);
		System.out.println(a);

	}

	private static void upper_lowercase() {

		String s = "HeXaWarE";
		char[] ch = s.toCharArray();
		StringBuilder b = new StringBuilder();
		int uppercount = 0;
		int lowercount = 0;

		for (int i = 0; i < ch.length; i++) {

			if (Character.isUpperCase(ch[i])) {
				System.out.println("Uppercase words  " + ch[i]);
				char lowerCase = Character.toLowerCase(ch[i]);
				b.append(lowerCase);
				uppercount++;
			} else if (Character.isLowerCase(ch[i])) {
				System.out.println("Lowercase words  " + ch[i]);
				char upperCase = Character.toUpperCase(ch[i]);
				b.append(upperCase);
				lowercount++;
				System.out.println("lowercase count " + lowercount + "  " + ch[i]);
			}

		}
		String sorted = new String(b.toString());
		System.out.println("Wise versa word  " + b);
//		System.out.println("Uppercase count "+uppercount);
//		System.out.println("lowercase count "+lowercount);	

	}

	private static void ascendingalpha() {
//		String a = "dcba";
		int[] ch = { 1, 3, 4, 5 };
//		char[] ch = a.toCharArray();
		for (int i = 0; i < ch.length; i++) {

			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] > ch[j]) {
					int next = ch[i];
					ch[i] = ch[j];
					ch[j] = next;

				}
			}
			System.out.println(ch[i]);
		}

		for (int num : ch) {
			System.out.print(num + " ");
		}
	}

	private static void anagram() {
		String a = "listen";
		String b = "silent";
		char[] charArray = b.toCharArray();
		char[] charArray2 = a.toCharArray();
		int length2 = charArray.length;
		int length = a.length();
		System.out.println(length2);
		Arrays.sort(charArray2);
		Arrays.sort(charArray);
		String a1 = new String(charArray2);
		String a2 = new String(charArray);
		if (a1.equals(a2)) {
			System.out.println("Yes Equals also Working its a anagaram");

		} else {
			System.out.println("its not a Anagram");

		}

		boolean equals = Arrays.equals(charArray, charArray2);

		if (equals) {
			System.out.println("Yes its anagram");
		} else {
			System.out.println("its not  anagram");
		}
	}

	private static void prefix_suffix() {
		String[] a = { "flower", "float", "floor" };
		String[] b = { "running", "talking", "speaking" };
		String prefix = a[0];
		String suffix = b[0];
		for (int i = 0; i < a.length; i++) {
			while (!a[i].startsWith(prefix)) {
				prefix = prefix.substring(0, prefix.length() - 1);
			}
		}
		System.out.println(prefix);

		for (int i = 0; i < b.length; i++) {
			while (!b[i].endsWith(suffix)) {
				suffix = suffix.substring(1);
			}
		}
		System.out.println(suffix);
	}

	private static void string_Occrance() {
		String a = "gopala";
		char[] ch = a.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			// char ch = a.charAt(i);
			if (ch[i] == 0)
				continue;
			int cont = 1;
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					cont++;
					ch[j] = 0;
				}
			}
			if (cont == 1) {
				System.out.println("one occured string  " + ch[i] + "  " + +cont);
			} else {
				System.out.println("twice or more than twice occured " + ch[i] + " " + cont);
			}
		}
		
		
		
	}
	private void longestsubstring() {
		// TODO Auto-generated method stub
String a = "heherex";
		
		char[] ch = a.toCharArray();
		
		String l="";
		 for (int i = 0; i < ch.length; i++) {
			 String b = "";
			
			 for (int j = i+1; j < ch.length; j++) {
				 boolean isprime = true;
				String sub= a.substring(i, j);
				int R =0;
				int L = sub.length()-1;
				while (R<L) {
					//longest paplindrome substring
					if (sub.charAt(R)!=sub.charAt(L)) {
						isprime = false;
						break;
					}
					
					R++;
					L--;
					
				}
				
				 if (isprime&&l.length() < sub.length()) {
						l=sub;
					}	
				//longest sub String
				 
//				if (b.indexOf(ch[j])!=-1) {
//					break;
//				}
//				 b+=ch[j];
				 
			}
			
			 
		}
		 
		 System.out.println(l);
	}

	public static void main(String[] args) {
//		duplicate_based_string_program();
//		asce_desc_string();
//		duplicate_string();
//		resverse_string();
//		second_largest_charcter();
//		reeverse();
//		upper_lowercase();
//		ascendingalpha();
//		anagram();
//		prefix_suffix();
//		string_Occrance();
	}
}
