package javainterview_prepartion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Array_programs {

	static int[] a = { 2, 1, 4, 3,  5, 7, 7, 1 ,6};
	static int[] b = { 2, 1, 4, 3, 6, 5, 7, 7, 1, -1, -2, -5 };
@Test
	private static void find_second_largest_number() {
		int firstlargest = 0;
		int secondlargest = 0;
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
			if (a[i] > firstlargest) {
				secondlargest = firstlargest;
				firstlargest = a[i];
			}
			else if (a[i]>secondlargest && a[i] < firstlargest) {
				secondlargest = a[i];
			}
		}
		System.out.println(secondlargest);
		System.out.println("sum of the array  " + sum);
	}

	private static void min_max_numbers() {

		int min = a[0];
		int max = a[0];

		for (int i = 0; i < a.length; i++) {
			if (a[i] < min) {
				min = a[i];
			} else if (a[i] > max) {
				max = a[i];
			}
		}
		System.out
				.println("minimum number of the give array " + min + "  " + " maximum number in the given arry " + max);
	}

	private static void negative_positive_number() {
		int count = 0;

		for (int i = 0; i < b.length; i++) {
			if (b[i] > 0) {
				count++;
			}
			if (count == 2) {
				System.out.println(b[i]);
				break;
			}
		}
	}

	private static void uniquie_number() {
		for (int i = 0; i < a.length; i++) {
			if (a[i] == 0)continue;
			boolean isunique = true;
			int count = 1;
			for (int j = 0; j < a.length; j++) {
				if (i != j && a[i] == a[j]) {
					isunique = false;
					count++;
					a[j] = 0;
				}

			}
			if (count == 1) {
				System.out.println("Unique numbers " + count);
			}
		}

	}

	private static void remove_duplicate() {
		int[] a = { 2, 1, 1, 4, 3, 2};

		Set<Integer> set = new HashSet<>();
		Set<Integer> duplicate = new HashSet<>();

		for (int num : a) {

			if (!set.add(num)) {
				duplicate.add(num);
			}
		}
		set.removeAll(duplicate);
		System.out.println("Duplicate numbers  " + duplicate);
		System.out.println("Duplicate remove numbers  " + set);
	}

	private static void arraylist() {
		ArrayList<Integer> a = new ArrayList<Integer>();
		a.add(2);
		a.add(1);
		a.add(4);
		a.add(1);

		int min = a.get(0);

		for (int i = 0; i < a.size(); i++) {
			if (a.get(i) < min) {
				min = a.get(i);
			}

		}
		System.out.println(min);

	}

	private static void reverse_int() {
		int a = 54321;
		int rev = 0;
		while (a != 0) {
			int digit = a % 10;
			rev = rev * 10 + digit;
			a = a / 10;

		}
		System.out.println(rev);
	}

	private static void count_odd_even() {
		int[] a = { 1, 2, 3, 4, 6, 5, 7, 24 };

		for (int i = 0; i < a.length; i++) {

			if (a[i] % 2 == 0) {

				System.out.println("Even number" + a[i]);
			} else {
				System.out.println("odd number " + a[i]);

			}

		}

	}

	private static void primenumber() {
		Scanner input = new Scanner(System.in);
//		System.out.println("Enter the num");
//		int num = input.nextInt();
		
		int num = 10;
		int a = 0;
		for (int i = 2; i < num; i++) {
			System.out.println("Outer for loop for      I "+i);
			boolean isprime = true;
			for (int j = 2; j <i; j++) {
				System.out.println("Inner for loopfor I "+i);
				System.out.println("Inner for loopfor j "+j);
				if (i%j == 0) {	
					isprime = false;
//					break;
				}
			}
			if (isprime) {
				a+=i;
//				System.out.println("Value of i "+i+" Value of a "+a);
//				System.out.println(num + "  Yess its a prime number");
			} else {
//				System.out.println(num + "  Sorry its not a prime number");
			}
		}

			
		
	}

	private static void fibinoanci() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the num");
		int num = input.nextInt();
		int a = 0, b = 1;
		System.out.print(a + " " + b);
		for (int i = 2; i <= num; i++) {

			int next = a + b;
			System.out.print("  " + next);
			a = b;
			b = next;

		}

	}

	private static void factorial() {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the num");
		int num = input.nextInt();
		int fact = 1;
		for (int i = 1; i <= num; i++) {
			fact = fact * i;
		}
		System.out.println("Factorial number for " + num + " is " + fact);
	}

	private static void missingnumber() {

		int[] a = { 1, 2, 3, 4 };
		int n = a.length + 1;
		int b = n * (n + 1) / 2;
		int c = 0;

		for (int num : a) {
			c += num;
		}
		int missing = b - c;
		System.out.println("Missing number is  " + " " + missing);

	}

	private static void patt() {
		
		for (int i = 1; i <= 5; i++) {
			for (int j = 5 - i; j > 0; j--) {
				System.out.print(" ");
			}
			for (int k = 1; k <= i; k++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}

	private static void Add_twonumbers_rev() {
		int[] a = { 3, 2, 1 }, b = { 4, 3, 1 };

		int c = 0;
		int rev = 0;
		int d = 0;
		
// adding the number from array
		for (int num : a) {
			c = c * 10 + num;
			System.out.println("converted the array to int for a " +c);
		}
		
		for (int num : b) {
			d = d*10+num;
			System.out.println("converted the array to int for b " +d);
			
		}
		
		int sum = c+d;
		System.out.println("addaed sum the array  "+sum);
		
		int output = 0;
	while (sum!=0) {
		int digit = sum%10;
		output = output*10+digit;
		sum= sum/10;
	}
	System.out.println("The final reversed output "+output);
		
//		reverse the the int
		while (c != 0) {
			int digit = c % 10;
			rev = rev * 10 + digit;
			c = c / 10;
		}
		System.out.println(rev);
		
		// rev the array unsing forloop
		int mult = 1, e = 0;
		for (int i : b) {
			e += i * mult;
			mult *= 10;
		}
		System.out.println(e);

	}
	private static void roman() {
		int I =1,V=5,X=10,L=50;	
		System.out.println(V+X);
	}
	
	private  static void adding_twonum_untill_singledigit() {

		Set<Integer> b = new HashSet();
		Set<Integer> dup = new HashSet();
		ArrayList<Integer> arr = new ArrayList<>();
		int [] a = {1,2,3,1,2,9999};
		int num = 0;
		
		int reve= 123;
		int reverse = 0;
		int convert_array_to_int = 0;
		int e = 0;
		int g = 0;
		int rev = 0;
		for (int i : a) {
			while (i!=0) {
//			System.out.print(i%10);	
			int d = i%10;
			System.out.print(d);
			rev = rev*10+d;
				i= i/10;
			}
			
			while (reve!=0) {
				int digit = reve%10;
				reverse = reverse*10+digit;	
				reve = reve/10;
			}
			num+=i;
			
		}
		
		int intt = 12345675;
		
		while (intt!=0) {
			int k = intt%10;
			if (arr.add(k)) {
				System.out.println("int to array conversation "+arr);
			}
			intt= intt/10;
		}
		System.out.println(reverse);
		System.out.println("Value of rev "+rev);
		System.out.println("Value of Num "+num);
		while (num!=0 ) {
			e += num%10;
			System.out.println("value of e  "+e);
			num = num/10;
			System.out.println("Value of num in while "+num);
		}
		System.out.println("Printing Next loop ");
		while (e!=0) {
			g+= e%10;
			System.out.println("value of second e "+g);
			e=e/10;
			System.out.println("value of second e/10 "+e);

		}
		for (int num1 : a) {
			if (!b.add(num1)) {
				System.out.println("Value of num1 "+num1);
				dup.add(num1);
				System.out.println(dup);
			}
		}
	
	}
	public static void main(String[] args) {
//		find_second_largest_number();
//		min_max_numbers();
//		negative_positive_number();
//		uniquie_number();
//		remove_duplicate();
//		arraylist();
//		reverse_int();
//		count_odd_even();
		primenumber();
//		fibinoanci();
//		factorial();
//		missingnumber();
//		patt();
//		Add_twonumbers_rev();
//		roman();
//		adding_twonum_untill_singledigit();
		

	}
}
