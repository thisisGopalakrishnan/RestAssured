package javainterview_prepartion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.testng.annotations.Test;

public class Collections {
	
	private static void hashmap() {
		Map<String, String> a = new HashMap<>();
		a.put("Username", "GopalaKrishnan");
		a.put("Password", "erp@123");
		a.put(null, null);
		// its allow to enter but while printing one null only printed
		a.put(null, null);
		List<String> b = new ArrayList<>(a.keySet());
		List<String> c = new ArrayList<>(a.values());
		System.out.println(a.get("Username") + "  " + a.get("Password"));
		System.out.println(b.get(0));
		System.out.println(b.get(1));
		System.out.println(a.get("Username"));
		// Using for loop we can print all values from map
		for (Entry<String, String> d : a.entrySet()) {
			System.out.println(d.getKey() + " " + d.getValue());
		}
		// Using keyset for get all key Values

		Set<String> keySet = a.keySet();

		System.out.println("Keyset " + keySet);

		System.out.println(a.get("Password"));
	}

	private static void hash_duplicates() {

		int[] a = { 2, 3, 1, 2, 4, 5 };
		String b = "gopalakrishnan";
		char[] ch = b.toCharArray();
		System.out.println();

		Map<Character, Integer> map = new HashMap();
		Map<Integer, Integer> d = new HashMap();
		Integer integer2 = d.get(3);

		for (int c : a) {
			d.put(c, d.getOrDefault(c, 0) + 1);
		}

		Integer integer = d.getOrDefault(3, 0);
		System.out.println("Value of " + d.keySet());

		System.out.println("Integer value of " + d.get(2));
		for (Entry<Integer, Integer> entry : d.entrySet()) {
			if (entry.getValue() <= 1) {
				System.out.println(entry.getKey() + ":" + entry.getValue());
			}

		}

//		for (int f : a) {
//			
//			if (d.containsKey(f)) {
//			d.put(f, d.get(f)+1);
//			}
//			else {
//				d.put(f, 1);
//			}
//		}
//		System.out.println(d);

//		for (Entry<Integer , Integer> intt : d.entrySet() ) {
//			System.out.print(intt.getKey());
//			System.out.println();
//			System.out.print(intt.getValue());
//		}
		for (char c : ch) {
			if (map.containsKey(c)) {
				map.put(c, map.get(c) + 1);

			} else {
				map.put(c, 1);
			}
//			map.put(c, map.getOrDefault(c, 0)+1);
		}
		System.out.println(map);

		for (Entry<Character, Integer> entry : map.entrySet()) {
			if (entry.getValue() == 1) {
				System.out.println("value  " + entry.getKey() + "" + entry.getValue());
			}
		}
		// latest way to find duplicate it support only in Java 8
//			map.put(i, map.getOrDefault(i, 0) + 1);

	}

	private static void duplicate_char() {
		String a = "gopalp";
		char[] name = a.toCharArray();
		String b = "aieous";
		char[] charArray = b.toCharArray();

		Map<Character, Integer> map = new HashMap<>();
		Map<Character, Integer> map1 = new HashMap<>();
		List<Character> d = new ArrayList<>();

		for (char character : charArray) {

			d.add(character);
		}

		for (char ch : name) {

			if (d.contains(ch)) {
				map.put(ch, map.getOrDefault(ch, 0) + 1);
			}
		}

		for (Entry<Character, Integer> ent : map.entrySet()) {
			System.out.println(ent.getKey() + "  " + ent.getValue());
		}

//		System.out.println(map);
	}

	private static void numbers() {
		int[] a = { 1, 2, 3, 4 };
		int[] b = { 4, 5, };

		Map<Integer, Integer> map = new HashMap<>();
		List<Integer> c = new ArrayList<>();
		for (int integer : a) {
			c.add(integer);

		}
		for (int inte : b) {
			if (c.contains(inte)) {
				map.put(inte, map.getOrDefault(inte, 0) + 1);
			}

		}
		for (Entry<Integer, Integer> entry : map.entrySet()) {
			System.out.println(entry.getKey() + "  " + entry.getValue());
		}
	}
@Test
	private void latestforloop() {
		Map<Character, Integer> a = new HashMap<>();

		String b = "programming";

		char[] charArray = b.toCharArray();

		for (char c : charArray) {

			a.put(c, a.getOrDefault(c, 0) + 1);

		}
		System.out.println(a);

		for (Entry<Character, Integer> d: a.entrySet()) {
			if (d.getValue()>1) {
				System.out.println(d.getValue());
			}
		}
		
		
		for (char c : charArray) {
			
			if (a.containsKey(c)) {
				a.put(c, a.get(c)+1);
			}
			else {
				a.put(c, 1);
			}
			
		}
		
		
		
		
		
	}

	public static void main(String[] argus) {

		// hashmap();
//		 hash_duplicates();
//		 duplicate_char();
//	 	 numbers();

	}

}
