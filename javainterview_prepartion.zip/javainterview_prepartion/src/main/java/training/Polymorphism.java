package training;

import org.apache.commons.math3.stat.descriptive.summary.Sum;

public class Polymorphism {
/*
 * method Overloading same method name but 
 * parameter diff and count of paramter diff
 * */
	public  void add(int a , int b) {
		int c = a+b;
		System.out.println(c);
	}
	public static void add(int a , double b) {
		int c = (int) (a+b);
		System.out.println(c);
	}
	public static void add(double a , double b) {
		double c = a+b;
		System.out.println(c);
	}
	
	public static void main(String[] args) {
//		add(2,3.5);
	}
}

class B extends Polymorphism{
	
	@Override
	public void add(int a, int b) {
//		super.add(a, b);
		int c = a/b;
		System.out.println(c);
	}
	
}

class Overrriding extends Polymorphism  {
	
	@Override
	public  void add(int a, int b) {
	
		int c = a*b;
		System.out.println(c);
//		super.add(a, b);
	}
	
	public void Sum() {
		System.out.println("method belongs to class");
	}
	
public static void main(String[] args) {
	Polymorphism a = new Overrriding();
	Polymorphism b = new B();
	a.add(2, 4);
	b.add(6, 2);
	
	
}

private static void test(Polymorphism a) {
	// TODO Auto-generated method stub
	
}
}