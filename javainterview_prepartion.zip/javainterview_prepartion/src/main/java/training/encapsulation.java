package training;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import lombok.Setter;

/* encapsulation means bundle of the wrap into single unit
 * make it variable or method private and access through getter seter
 * using getter setter we can access the fuction or varibale 
 * */
public class encapsulation {

	WebDriver driver;
	private static int a = 10;
	
	private void set(WebDriver driver) {
		this.driver=driver;
		
	}
	public WebDriver Gett() {
		return driver;
	}
	
	
	private void Setter(int a) {
this.a= a;

	}
	
	public static int getter() {
		return a;
	}
	
	
	@FindBy (xpath = "(//select[@class='form-control small-view ng-untouched ng-pristine ng-valid ng-star-inserted'])[2]")
	public  WebElement Store_Unit;
	
	
	private void setter(WebElement savStore_Unite) {
		this.Store_Unit= Store_Unit;

	}
	
	public WebElement Store_Unit() {
		return Store_Unit;

	}
	
	public static void main(String[] args) {
	System.out.println(getter());
	encapsulation a = new encapsulation();
	a.Setter(20);
	System.out.println(getter());
	System.out.println(a.Store_Unit());
	}

}
