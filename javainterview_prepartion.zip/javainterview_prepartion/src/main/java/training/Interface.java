package training;

/*
* Interface has abstract methods( dont have body )
* We cannot create object for an Interface
* In java 8 Interface support Default and static methods it has body.
* static method belongs to interface class it self
  -We can call the method by interface name itself
* Using implements key word in the child class we can use the interface methods
* once we implement the interface in the class we have to we have to use all the methods in the child class 
* We can achieve multiple inheritance via implements.
*/


interface Vehicle{
	
	default void car() {
		System.out.println("Default method from interface");
	}
	
	void bus();
	
	static void bike() {
		System.out.println("Static method from interface");
		
	}
		
}

class Start implements Vehicle {
	
	public void statingclass() {
System.out.println("methods belongs to class");
	}

	@Override
	public void bus() {
System.out.println("Override method from the child class");		
	}
		
	public static void main(String[] args) {	
		Start a = new Start();
		a.car();
		a.bus();
		a.statingclass();
		Vehicle.bike();
	}
}

