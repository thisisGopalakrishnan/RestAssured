package training;

/*
 * we cannot create instance for abstract class
 * Abstract class have abstract (Method has no body) method and concreate method
 * in the child class we can create he object for 
  -child class and with reference with abstract class
 * this is called upcasting and runtime polymorphism
 */

abstract class Abstract{
	
	//Abstract Method
	 abstract void car();
	 //Abstract method with public access modifier
	public abstract void bus();
	//Abstract concrete method
	void bike() {
		System.out.println("Concrete methods from abstract class");	
	}
	
	}

class A extends Abstract{
	 
	public void classmethod() {
		System.out.println("Runns from child class method");
		double a = 12.65;
		int b = (int) a;
		System.out.println(b);
		int c = 13;
		double d = (double) c;
		System.out.println(d);
	}
	
	@Override
	void car() {
System.out.println("car method runs from child class override from parent ");		
	}

	@Override
	public void bus() {
	System.out.println("Bus method runs from child class override from parent ");		
		
	}
	
	public static void main(String[] args) {
		A b = new A(); 
		b.classmethod();
		b.bike();
		b.bus();
	}
	
}
