package training;



public class Constructor {

	Constructor(){
		System.out.println("default from Parent constrctor ");
	}
	Constructor(int a , int b){
	int c = a+b;
	System.out.println("parameterized constrcutor from parent class "+c);
	}
	
	Constructor(int a , String b){
		String c = a+b;
		System.out.println("parameterized constrcutor from parent class "+c);
		int d = 1;
		String e = String.valueOf(d);
		System.out.println(e);
	}
		
	
	
	public static void main(String[] args) {
		Constructor a = new Constructor(1,"hello");
	}
	
}

class V extends Constructor{
	/* parent constrcutor must have deafault constructor so that
	parent constructor execute first and child class execute
	if 
	panrent dont have constrcutor in child class me ust have constrctor 
	*/
	
	V(){
		super(1, "Goapl");
		System.out.println("Child class default constrctor");
		
	}
	public void divide() {
		
		System.out.println("Child class method divide");
	} 
	
	public static void main(String[] args) {
		V a = new V();
		a.divide();
	}
	
}




